from flask import Flask, request, render_template, jsonify
import subprocess
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run-tests', methods=['POST'])
def run_tests():
    test_file_path = 'D:/playwright_automation/Run/test_mfs_admin_portal.py'
    report_path = 'D:/playwright_automation/Run/report.html'
    
    if os.path.exists(test_file_path):
        # Run the tests
        result = subprocess.run(['pytest', '-v', test_file_path, '--html=' + report_path], capture_output=True, text=True)
        
        # Check if the report file was created
        if os.path.exists(report_path):
            # Read the content of the report file
            with open(report_path, 'r', encoding='utf-8') as file:
                report_content = file.read()

            # Send the report content to the client
            return jsonify({"status": "Tests completed successfully", "report": report_content})
        else:
            return jsonify({"status": "Report file not found", "report": ""})
    else:
        return jsonify({"status": "Test file not found", "report": ""})

if __name__ == "__main__":
    app.run(debug=True)
