from flask import Flask, render_template, send_from_directory, jsonify
import subprocess
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run-tests', methods=['POST'])
def run_tests():
    try:
        # Run the tests and generate Allure results
        subprocess.run(["pytest", "--alluredir=allure-results"], check=True)
        
        # Generate the Allure report
        allure_cmd_path = r'C:\Users\khaled.showkot\AppData\Roaming\npm\allure.cmd'
        subprocess.run([allure_cmd_path, "generate", "allure-results", "--clean", "-o", "allure-report"], check=True)
        
        # Return the path to the generated report
        return jsonify({'message': 'Tests completed successfully', 'report': '/allure-report/index.html'})
    except subprocess.CalledProcessError as e:
        return jsonify({'error': 'Error running tests or generating report'}), 500

@app.route('/allure-report/<path:filename>')
def serve_report(filename):
    return send_from_directory('allure-report', filename)

if __name__ == '__main__':
    app.run(debug=True)
